const startingData = [
    {
        "Date": "3/4/2017",
        "Close": 97.53
      },
      {
        "Date": "10/2/2016",
        "Close": 80.42
      },
      {
        "Date": "5/2/2016",
        "Close": 86.33
      },
      {
        "Date": "12/5/2015",
        "Close": 68.37
      },
      {
        "Date": "7/1/2015",
        "Close": 83.15
      },
      {
        "Date": "2/1/2015",
        "Close": 62.02
      },
      {
        "Date": "9/4/2014",
        "Close": 54.65
      },
      {
        "Date": "5/4/2014",
        "Close": 55.66
      },
      {
        "Date": "12/2/2013",
        "Close": 52.97
      },
      {
        "Date": "7/3/2013",
        "Close": 46.95
      },
      {
        "Date": "2/2/2013",
        "Close": 39.89
      },
      {
        "Date": "9/4/2012",
        "Close": 39.07
      },
      {
        "Date": "4/4/2012",
        "Close": 35.78
      },
      {
        "Date": "11/1/2011",
        "Close": 35.09
      },
      {
        "Date": "6/2/2011",
        "Close": 44.62
      },
      {
        "Date": "2/2/2011",
        "Close": 43.86
      },
      {
        "Date": "9/2/2010",
        "Close": 43.23
      },
      {
        "Date": "4/2/2010",
        "Close": 39.31
      },
      {
        "Date": "11/3/2009",
        "Close": 29.22
      },
      {
        "Date": "6/3/2009",
        "Close": 24.8
      },
      {
        "Date": "1/3/2009",
        "Close": 26.95
      }
]

const min = Math.min(...startingData.map(d => d.Close))
const max = Math.max(...startingData.map(d => d.Close))

const minDate = Math.min(...startingData.map(d => +new Date(d.Date)))
const maxDate = Math.max(...startingData.map(d => +new Date(d.Date)))

const gen = (min, max) => {
    return Math.random() * (max - min) + min;
}

// console.log(min, max, new Date(minDate).toLocaleDateString("en-us"), new Date(maxDate).toLocaleDateString("en-us"))

while (startingData.length < 50) {
    startingData.push({
        Date: new Date(gen(minDate, maxDate)).toLocaleDateString("en-us"),
        Close: Math.round(gen(min, max) * 100) / 100
    });
}

console.log(startingData.sort((a, b) => +new Date(b.Date) - new Date(a.Date)))