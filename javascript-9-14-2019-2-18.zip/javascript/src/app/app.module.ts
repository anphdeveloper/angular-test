import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule, ReactiveFormsModule } from "@angular/forms"; // <-- NgModel lives here
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { AgGridModule } from 'ag-grid-angular';
import 'ag-grid-enterprise';
import { SubchartComponent } from './subchart/subchart.component';
import { ButtonComponent } from './button/button.component';
import { GridChartComponent } from './grid-chart/grid-chart.component';
import { TitleComponent } from './title/title.component';
import { NglModule } from 'ng-lightning';
import { SettingsComponent } from './settings/settings.component';
import { TopMenuComponent } from './top-menu/top-menu.component';
import { BalanceSheetReportComponent } from './balance-sheet-report/balance-sheet-report.component';
import { SideMenuComponent } from './side-menu/side-menu.component';
import { PostAccountingEventsComponent } from './post-accounting-events/post-accounting-events.component';

@NgModule({
  declarations: [
    AppComponent,
    SubchartComponent,
    ButtonComponent,
    GridChartComponent,
    TitleComponent,
    SettingsComponent,
    TopMenuComponent,
    BalanceSheetReportComponent,
    SideMenuComponent,
    PostAccountingEventsComponent,
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule,
    ReactiveFormsModule,
    NglModule,
    BrowserAnimationsModule,
    AgGridModule.withComponents([SubchartComponent, ButtonComponent, GridChartComponent])
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
