import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

/* Provides app with update state when buttons are pressed */

@Injectable({
  providedIn: 'root'
})
export class ChartService {
  private source = new Subject<any>();

  sourceChanged$ = this.source.asObservable();

  constructor() { }

  changeSource(data: string) {
    this.source.next(data);
  }
}
