import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-post-accounting-events',
  templateUrl: './post-accounting-events.component.html',
  styleUrls: ['./post-accounting-events.component.scss']
})
export class PostAccountingEventsComponent implements OnInit {

  n: number = 1000;

  accountingNumber: number = 1000;
  subledgerNumber: number = 0;

  accountingClass: string = "";
  subledgerClass: string = "empty";

  key: any;
  Arr = Array;
  active: boolean = true;

  constructor() { }

  ngOnInit() {

  }

  start() {
    const cssVars = document.getElementById("content-container").style;
    const inc = 2;

    this.active = true;

    this.key = setInterval(() => {
      if (this.subledgerNumber >= this.n) {
        clearInterval(this.key);
        this.accountingClass = "empty";
        this.active = false;
        return;
      } else {
        this.subledgerClass = "";
      }

      this.accountingNumber -= inc;
      this.subledgerNumber += inc;

      cssVars.setProperty("--accounting-y", "" + Math.round(this.accountingNumber / this.n * 150 + 50) + "px");
      cssVars.setProperty("--subledger-y", "" + Math.round(this.subledgerNumber / this.n * 150 + 50) + "px");
    }, 0);
  }

  stop() {
    clearInterval(this.key);
    this.active = false;
  }

}
