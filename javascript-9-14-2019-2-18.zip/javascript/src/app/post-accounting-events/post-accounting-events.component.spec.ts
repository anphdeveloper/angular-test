import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PostAccountingEventsComponent } from './post-accounting-events.component';

describe('PostAccountingEventsComponent', () => {
  let component: PostAccountingEventsComponent;
  let fixture: ComponentFixture<PostAccountingEventsComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PostAccountingEventsComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PostAccountingEventsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
