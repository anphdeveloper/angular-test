import { Injectable } from '@angular/core';
import { Subject } from 'rxjs';

/* Provides app with data rendered in the chart */

@Injectable({
  providedIn: 'root'
})
export class DataService {
  private source = new Subject<any>();

  sourceChanged$ = this.source.asObservable();

  private variance: number = 1.9;
  private min: number = 0.1;

  genSkew() {
    return Math.round(((this.variance * Math.random()) + this.min) * 1000) / 1000;
  }

  constructor() {
    if (!localStorage.getItem("settings")) {
      localStorage.setItem("settings", JSON.stringify([ "Default" ]));
    }

    // initial data loaded in
    let data: any = {
      date: new Date(new Date().getTime() - (new Date().getTimezoneOffset() * 60000 ))
        .toISOString()
        .split("T")[0],
      title: "Balance Sheet",
      location: "XYZ Bank",
      nameLabel: "Assests Subledger",
      setting: "Default",
      settings: localStorage.getItem("settings"),
      cols: [
        "Mortgages", "Consumer Loans", "Securities", "Debt & Derivatives"
      ],
      rowData: [
      {
        name: 'Federal Funds Sold', cols: {
          2: {
            balance: "166908",
            confidence: { number: 750, skew: this.genSkew() }
          }
        }
      },
      {
        name: 'Residential Mortgages, Net', cols: {
          0: {
            balance: "166908", 
            confidence: { number: 12500, skew: this.genSkew() }
          }
        }
      },
      {
        name: 'Credit Card Receivables', cols: {
          1: {
            balance: "92474", 
            confidence: { number: 50000, skew: this.genSkew() }
          }
        }
      },
      {
        name: 'Other Consumer Loans', cols: {
          1: {
            balance: "113132", 
            confidence: { number: 34000, skew: this.genSkew() }
          }
        }
      },
      {
        name: 'Commercial Loans', cols: {
          1: {
            balance: "103927",
            confidence: { number: 65000, skew: this.genSkew() }
          }
        }
      },
      {
        name: 'Investment Securities', cols: {
          2: {
            balance: "80215",
            confidence: { number: 28000, skew: this.genSkew() }
          }
        }
      },
      {
        name: 'Derivative Assets', cols: {
          3: {
            balance: "826",
            confidence: { number: 20000, skew: this.genSkew() } 
          }
        }
      },
      { name: 'Cash and Cash Equivalents'},
    ]
  };

  data.rowData = data.rowData.map(d => {
    // add blank data for each column if it is unitialized

    data.cols.forEach((c, i) => {
      if (!d.cols) {
        d.cols = {};
      }
      if (!d.cols[i]) {
        d.cols[i] = { balance: "", confidence: { number: 0, skew: this.genSkew() } };
      }
      d.cols[i].confidence.maxRendered = d.cols[i].confidence.number;
      d.cols.length = data.cols.length;
    })

    return d;
  });

    setTimeout(() => {
      this.changeSource(
        data
      );
    }, 0);
  }

  changeSource(data: any) {
    if (!localStorage.getItem(data.setting) && data.setting !== "Default") {
      const settings = JSON.parse(localStorage.getItem("settings"));
      settings.push(data.setting);
      localStorage.setItem("settings", JSON.stringify(settings));
    }

    delete data.settings;
    localStorage.setItem(data.setting, JSON.stringify(data));

    data.settings = JSON.parse(localStorage.getItem("settings"));
    this.source.next(data);
  }
}
