import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import { BalanceSheetReportComponent } from './balance-sheet-report/balance-sheet-report.component';
import { PostAccountingEventsComponent } from './post-accounting-events/post-accounting-events.component';

const routes: Routes = [
  // {
  //   path: "reports/balance-sheet", component: BalanceSheetReportComponent
  // },
  // {
  //   path: "subledgers/post-accounting-events", component: PostAccountingEventsComponent
  // },
  // {
  //   path: "", redirectTo: "/reports/balance-sheet", pathMatch: "full"
  // }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
