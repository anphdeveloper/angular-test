import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-top-menu',
  templateUrl: './top-menu.component.html',
  styleUrls: ['./top-menu.component.scss']
})
export class TopMenuComponent implements OnInit {
  open: Array<boolean>;

  menus: any = [
    { title: "Accounting Events", items: [ 
      { name: "Import Accounting Events", link: "/" }, 
      { name: "Calculate Accounting Events", link: "/" },  
      { name: "Validate Accounting Events", link: "/" },  
      { name: "Register Accounting Events", link: "/" },  
      { name: "Approve Accounting Events", link: "/" },  
      { name: "Approve Events for Posting", link: "/" },  
    ] },
    { title: "Subledgers", items: [ 
      { name: "Post Accounting Events", link: "/subledgers/post-accounting-events" },  
      { name: "Manage Posting Rules", link: "/" },  
      { name: "Manage Periods", link: "/" },  
      { name: "Manage Ledgers", link: "/" },  
      { name: "Define Policy Bases", link: "/" }, 
    ] },
    { title: "Reports", items: [ 
      { name: "Report Browser", link: "/" },  
      { name: "Asset Browser", link: "/" },  
      { name: "Add Report", link: "/" },  
      { name: "Embed Report", link: "/" },  
      { name: "Create Storyboard", link: "/" }, 
      { name: "Explore Data", link: "/" },  
      ] },
    { title: "Dashboards", items: [ 
      { name: "Financial Dashboards", link: "/" }, 
      { name: "Reconciliation & Audit Dashboard", link: "/" }, 
      { name: "Processing Dashboard", link: "/" } 
    ] },
    { title: "Documents", items: [ 
      { name: "Document Library", link: "/" } 
    ] },
  ];

  constructor() {
    this.open = Array(this.menus.length).fill(false);
   }

  ngOnInit() {
  }

}
