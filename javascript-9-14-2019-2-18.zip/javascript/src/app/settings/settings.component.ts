import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';

@Component({
  selector: 'app-settings',
  templateUrl: './settings.component.html',
  styleUrls: ['./settings.component.scss']
})
export class SettingsComponent implements OnInit {

  data: any = { cols: [], rowData: [] };
  first: boolean = true;
  settings: FormGroup;
  hide: string = "hide";

  constructor(private _DS: DataService, private formBuilder: FormBuilder) { }

  ngOnInit() {
    const options = {};
    
    // initialize form options for every row and column
    for (let i = 0; i < 8; i++) {
      options[`${i}-name`] = [ "", Validators.required ];

      for (let j = 0; j < 4; j++) {
        options[`${i}-${j}-number`] = [ "", Validators.required ];
        options[`${i}-${j}-maxRendered`] = [ "", Validators.required ];
        options[`${i}-${j}-skew`] = [ "", Validators.required ];
        options[`${i}-${j}-balance`] = [ "", Validators.required ];

        if (i === 0) {
          options[`col-name-${j}`] = [ "", Validators.required ];
        }
      }
    }

    options["name-label"] = [ "", Validators.required ];
    options["location"] = [ "", Validators.required ];
    options["title"] = [ "", Validators.required ];
    options["date"] = [ "", Validators.required ];
    options["setting"] = [ "", Validators.required ];
    options["add-setting"] = [ "", Validators.nullValidator ];

    // create form binding
    this.settings=this.formBuilder.group(options);

    // when data changes, update default form values
    this._DS.sourceChanged$.subscribe(e => {
      // prevents updating itself (this component updates the data)
      if (this.first) {
        this.data = e;
        this.first = false;
        const obj = {};

        // iterate through each row and column to give default values according to the data
        e.rowData.forEach((d, i) => {
          obj[`${i}-name`] = d.name;
          e.cols.forEach((c, j) => {
            obj[`${i}-${j}-number`] = d.cols[j].confidence.number;
            obj[`${i}-${j}-maxRendered`] = d.cols[j].confidence.maxRendered;
            obj[`${i}-${j}-skew`] = d.cols[j].confidence.skew;
            obj[`${i}-${j}-balance`] = d.cols[j].balance;

            if (i === 0) {
              obj[`col-name-${j}`] = c;
            }
          });
        });

        obj["name-label"] = this.data.nameLabel;
        obj["location"] = this.data.location;
        obj["title"] = this.data.title;
        obj["date"] = this.data.date;
        obj["setting"] = this.data.setting;
        obj["add-setting"] = this.settings.value["add-setting"];

        // finialize updates
        this.settings.setValue(obj);
      }
    })
  }

  submit() {
    // inform app of updates to data
    // updates all fields for rows and columns
    // reprocesses number by removing $ and , and then formating it correctly
    // also defualts max rendered to the number of data that are present
    this.data.rowData = this.data.rowData.map((d, i) => {
      d.name = this.settings.value[`${i}-name`];
      this.data.cols.forEach((c, j) => {
        d.cols[j].confidence.number = this.settings.value[`${i}-${j}-number`];
        d.cols[j].confidence.maxRendered = this.settings.value[`${i}-${j}-maxRendered`] || d.cols[j].confidence.number;
        d.cols[j].confidence.skew = this.settings.value[`${i}-${j}-skew`];
        d.cols[j].balance = "$" + Number(this.settings.value[`${i}-${j}-balance`].replace(/[$,]/g, "")).toLocaleString("en-US");
        
        if (i === 0) {
          this.data.cols[j] = this.settings.value[`col-name-${j}`];
        }
      })
      return d;
    });

    this.data.nameLabel = this.settings.value["name-label"];
    this.data.location = this.settings.value["location"];
    this.data.title = this.settings.value["title"];
    this.data.date = this.settings.value["date"];

    this._DS.changeSource(this.data);
    this.hide = "hide";
  }

  show() {
    // adds hide class to hide form appropiately
    if (this.hide !== "") {
      this.hide = "";
    } else {
      this.hide = "hide";
    }
  }

  addCol() {
    this.submit();
    this.hide = "";

    const j = this.data.cols.length;
    this.data.cols.push("Column " + (this.data.cols.length + 1));

    this.data.rowData = this.data.rowData.map((d, i) => {
      d.cols[j] = {
        confidence: {
          number: 0,
          maxRendered: 0,
          skew: this._DS.genSkew()
        },
        balance: ""
      }

      return d;
    });

    this.data.rowData.forEach((d, i) => {
      this.settings.addControl(`${i}-${j}-number`, new FormControl([ "", Validators.required ]));
      this.settings.addControl(`${i}-${j}-maxRendered`, new FormControl([ "", Validators.required ]));
      this.settings.addControl(`${i}-${j}-skew`, new FormControl([ "", Validators.required ]));
      this.settings.addControl(`${i}-${j}-balance`, new FormControl([ "", Validators.required ]));

      if (i === 0) {
        this.settings.addControl(`col-name-${j}`, new FormControl([ "", Validators.required ]));
      }
    });

    const obj = {};

    // iterate through each row and column to give default values according to the data
    this.data.rowData.forEach((d, i) => {
      obj[`${i}-name`] = d.name;
      this.data.cols.forEach((c, j) => {
        obj[`${i}-${j}-number`] = d.cols[j].confidence.number;
        obj[`${i}-${j}-maxRendered`] = d.cols[j].confidence.maxRendered;
        obj[`${i}-${j}-skew`] = d.cols[j].confidence.skew;
        obj[`${i}-${j}-balance`] = d.cols[j].balance;

        if (i === 0) {
          obj[`col-name-${j}`] = c;
        }
      });
    });

    obj["name-label"] = this.data.nameLabel;
    obj["location"] = this.data.location;
    obj["title"] = this.data.title;
    obj["date"] = this.data.date;
    obj["setting"] = this.data.setting;
    obj["add-setting"] = this.settings.value["add-setting"];

    // finialize updates
    this.settings.setValue(obj);
  }

  delCol(j) {
    this.submit();
    this.hide = "";

    this.data.cols.splice(j, 1);

    setTimeout(() => {
      const options = {};
      
      // initialize form options for every row and column
      for (let i = 0; i < this.data.rowData.length; i++) {
        options[`${i}-name`] = [ "", Validators.required ];

        for (let j = 0; j < this.data.cols.length; j++) {
          options[`${i}-${j}-number`] = [ "", Validators.required ];
          options[`${i}-${j}-maxRendered`] = [ "", Validators.required ];
          options[`${i}-${j}-skew`] = [ "", Validators.required ];
          options[`${i}-${j}-balance`] = [ "", Validators.required ];

          if (i === 0) {
            options[`col-name-${j}`] = [ "", Validators.required ];
          }
        }
      }

      options["name-label"] = [ "", Validators.required ];
      options["location"] = [ "", Validators.required ];
      options["title"] = [ "", Validators.required ];
      options["date"] = [ "", Validators.required ];
      options["setting"] = [ "", Validators.required ];
      options["add-setting"] = [ "", Validators.nullValidator ];

      // create form binding
      this.settings=this.formBuilder.group(options);

      const obj = {};

      // iterate through each row and column to give default values according to the data
      this.data.rowData.forEach((d, i) => {
        obj[`${i}-name`] = d.name;

        this.data.cols.forEach((c, j) => {
          obj[`${i}-${j}-number`] = d.cols[j].confidence.number;
          obj[`${i}-${j}-maxRendered`] = d.cols[j].confidence.maxRendered;
          obj[`${i}-${j}-skew`] = d.cols[j].confidence.skew;
          obj[`${i}-${j}-balance`] = d.cols[j].balance;

          if (i === 0) {
            obj[`col-name-${j}`] = c;
          }
        })
      });

      obj["name-label"] = this.data.nameLabel;
      obj["location"] = this.data.location;
      obj["title"] = this.data.title;
      obj["date"] = this.data.date;
      obj["setting"] = this.data.setting;
      obj["add-setting"] = this.settings.value["add-setting"];

      // finialize updates
      this.settings.setValue(obj);

      this.submit();
      this.hide = "";
    }, 0);
  }

  delRow(i) {
    this.submit();
    this.hide = "";
    
    this.data.rowData.splice(i, 1);

    setTimeout(() => {
      const options = {};
      
      // initialize form options for every row and column
      for (let i = 0; i < this.data.rowData.length; i++) {
        options[`${i}-name`] = [ "", Validators.required ];

        for (let j = 0; j < this.data.cols.length; j++) {
          options[`${i}-${j}-number`] = [ "", Validators.required ];
          options[`${i}-${j}-maxRendered`] = [ "", Validators.required ];
          options[`${i}-${j}-skew`] = [ "", Validators.required ];
          options[`${i}-${j}-balance`] = [ "", Validators.required ];

          if (i === 0) {
            options[`col-name-${j}`] = [ "", Validators.required ];
          }
        }
      }

      options["name-label"] = this.data.nameLabel;
      options["location"] = [ "", Validators.required ];
      options["title"] = [ "", Validators.required ];
      options["date"] = [ "", Validators.required ];
      options["setting"] = [ "", Validators.required ];
      options["add-setting"] = [ "", Validators.nullValidator ];

      // create form binding
      this.settings=this.formBuilder.group(options);

      const obj = {};

      // iterate through each row and column to give default values according to the data
      this.data.rowData.forEach((d, i) => {
        obj[`${i}-name`] = d.name;

        this.data.cols.forEach((c, j) => {
          obj[`${i}-${j}-number`] = d.cols[j].confidence.number;
          obj[`${i}-${j}-maxRendered`] = d.cols[j].confidence.maxRendered;
          obj[`${i}-${j}-skew`] = d.cols[j].confidence.skew;
          obj[`${i}-${j}-balance`] = d.cols[j].balance;

          if (i === 0) {
            obj[`col-name-${j}`] = c;
          }
        })
      });

      obj["name-label"] = this.data.nameLabel;
      obj["location"] = this.data.location;
      obj["title"] = this.data.title;
      obj["date"] = this.data.date;
      obj["setting"] = this.data.setting;
      obj["add-setting"] = this.settings.value["add-setting"];

      // finialize updates
      this.settings.setValue(obj);

      this.submit();
      this.hide = "";
    }, 0);
  }

  addRow() {
    this.submit();
    this.hide = "";

    this.data.rowData.push({
      name: "",
      cols: { length: this.data.cols.length }
    });

    this.data.cols.forEach((c, j) => {
      this.data.rowData[this.data.rowData.length - 1].cols[j] = {
          confidence: {
            number: 0,
            maxRendered: 0,
            skew: this._DS.genSkew()
          },
          balance: ""
      };
    });

    const i = this.data.rowData.length - 1;
    this.settings.addControl(`${i}-name`, new FormControl([ "", Validators.required ]));
    this.data.cols.forEach((c, j) => {
      this.settings.addControl(`${i}-${j}-number`, new FormControl([ "", Validators.required ]));
      this.settings.addControl(`${i}-${j}-maxRendered`, new FormControl([ "", Validators.required ]));
      this.settings.addControl(`${i}-${j}-skew`, new FormControl([ "", Validators.required ]));
      this.settings.addControl(`${i}-${j}-balance`, new FormControl([ "", Validators.required ]));
    });

    const obj = {};

    // iterate through each row and column to give default values according to the data
    this.data.rowData.forEach((d, i) => {
      obj[`${i}-name`] = d.name;
      this.data.cols.forEach((c, j) => {
        obj[`${i}-${j}-number`] = d.cols[j].confidence.number;
        obj[`${i}-${j}-maxRendered`] = d.cols[j].confidence.maxRendered;
        obj[`${i}-${j}-skew`] = d.cols[j].confidence.skew;
        obj[`${i}-${j}-balance`] = d.cols[j].balance;

        if (i === 0) {
          obj[`col-name-${j}`] = c;
        }
      });
    });

    obj["name-label"] = this.data.nameLabel;
    obj["location"] = this.data.location;
    obj["title"] = this.data.title;
    obj["date"] = this.data.date;
    obj["setting"] = this.data.setting;
    obj["add-setting"] = this.settings.value["add-setting"];

    // finialize updates
    this.settings.setValue(obj);
  }

  settingUpdate() {
    const val = this.settings.value["setting"];

    this.submit();
    this.hide = "";

    this.data = JSON.parse(localStorage.getItem(val));
    this.data.settings = JSON.parse(localStorage.getItem("settings"));

    const options = {};
    
    // initialize form options for every row and column
    for (let i = 0; i < this.data.rowData.length; i++) {
      options[`${i}-name`] = [ "", Validators.required ];

      for (let j = 0; j < this.data.cols.length; j++) {
        options[`${i}-${j}-number`] = [ "", Validators.required ];
        options[`${i}-${j}-maxRendered`] = [ "", Validators.required ];
        options[`${i}-${j}-skew`] = [ "", Validators.required ];
        options[`${i}-${j}-balance`] = [ "", Validators.required ];

        if (i === 0) {
          options[`col-name-${j}`] = [ "", Validators.required ];
        }
      }
    }

    options["name-label"] = this.data.nameLabel;
    options["location"] = [ "", Validators.required ];
    options["title"] = [ "", Validators.required ];
    options["date"] = [ "", Validators.required ];
    options["setting"] = [ "", Validators.required ];
    options["add-setting"] = [ "", Validators.nullValidator ];

    // create form binding
    this.settings=this.formBuilder.group(options);

    const obj = {};

    // iterate through each row and column to give default values according to the data
    this.data.rowData.forEach((d, i) => {
      obj[`${i}-name`] = d.name;

      this.data.cols.forEach((c, j) => {
        obj[`${i}-${j}-number`] = d.cols[j].confidence.number;
        obj[`${i}-${j}-maxRendered`] = d.cols[j].confidence.maxRendered;
        obj[`${i}-${j}-skew`] = d.cols[j].confidence.skew;
        obj[`${i}-${j}-balance`] = d.cols[j].balance;

        if (i === 0) {
          obj[`col-name-${j}`] = c;
        }
      })
    });

    obj["name-label"] = this.data.nameLabel;
    obj["location"] = this.data.location;
    obj["title"] = this.data.title;
    obj["date"] = this.data.date;
    obj["setting"] = this.data.setting;
    obj["add-setting"] = this.settings.value["add-setting"];

    // finialize updates
    this.settings.setValue(obj);
  }

  newSetting() {
    const val = this.settings.value["add-setting"];
    if (localStorage.getItem(val)) {
      return false;
    }
    this.data.setting = val;
    this.data.settings.push(val);
    localStorage.setItem("settings", JSON.stringify(this.data.settings));

    delete this.data.settings;
    localStorage.setItem(this.data.setting, JSON.stringify(this.data));

    this.data.settings = JSON.parse(localStorage.getItem("settings"));

    const obj = {};

    // iterate through each row and column to give default values according to the data
    this.data.rowData.forEach((d, i) => {
      obj[`${i}-name`] = d.name;
      this.data.cols.forEach((c, j) => {
        obj[`${i}-${j}-number`] = d.cols[j].confidence.number;
        obj[`${i}-${j}-maxRendered`] = d.cols[j].confidence.maxRendered;
        obj[`${i}-${j}-skew`] = d.cols[j].confidence.skew;
        obj[`${i}-${j}-balance`] = d.cols[j].balance;

        if (i === 0) {
          obj[`col-name-${j}`] = c;
        }
      });
    });

    obj["name-label"] = this.data.nameLabel;
    obj["location"] = this.data.location;
    obj["title"] = this.data.title;
    obj["date"] = this.data.date;
    obj["setting"] = this.data.setting;
    obj["add-setting"] = this.settings.value["add-setting"];

    // finialize updates
    this.settings.setValue(obj);
  }

  delSetting() {
    const val = this.data.setting;
    if (val === "Default") {
      return false;
    }

    this.data.settings.splice(this.data.settings.indexOf(val), 1);
    localStorage.setItem("settings", JSON.stringify(this.data.settings));
    localStorage.removeItem(val);

    this.data = JSON.parse(localStorage.getItem("Default"));
    this.data.settings = JSON.parse(localStorage.getItem("settings"));
  }

}
