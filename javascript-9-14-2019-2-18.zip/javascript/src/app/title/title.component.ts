import { Component, OnInit } from '@angular/core';
import { DataService } from '../data.service';

@Component({
  selector: 'app-title',
  templateUrl: './title.component.html',
  styleUrls: ['./title.component.scss']
})
export class TitleComponent implements OnInit {

  dateString: string;
  location: string;
  title: string;

  constructor(private _DS: DataService) { }

  ngOnInit() {
    this._DS.sourceChanged$.subscribe(data => {
      this.dateString = new Date(new Date(data.date).getTime() + new Date(data.date).getTimezoneOffset() * 60000).toLocaleDateString("en-US", { month: "long", day: "numeric", year: "numeric" });
      this.location = data.location;
      this.title = data.title;
    });
  }

}
