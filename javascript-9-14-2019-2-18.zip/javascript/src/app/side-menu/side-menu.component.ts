import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-side-menu',
  templateUrl: './side-menu.component.html',
  styleUrls: ['./side-menu.component.scss']
})
export class SideMenuComponent implements OnInit {

  menus: any = [
    { title: "Residential Mortgages", items: [ 
      { name: "Trial Balance", link: "/" }, 
      { name: "Balance Sheet", link: "/" }, 
      { name: "Income Statement", link: "/" }, 
      { name: "Parent Roll Forward", link: "/" }  
    ] },
    { title: "Securities", items: [
      { name: "Trial Balance", link: "/" },  
      { name: "Balance Sheet", link: "/" },  
      { name: "Income Statement", link: "/" },  
      { name: "Parent Roll Forward", link: "/" }  
    ] },
    { title: "Dimension Explorer", items: [ 
      { name: "Account - Book Value", link: "/" },  
      { name: "Account - Commercial GAAP", link: "/" },  
      { name: "Event - Cash Flow", link: "/" }  
    ] }
  ];

  show: boolean = true;

  constructor() { }

  ngOnInit() {
  }

}
