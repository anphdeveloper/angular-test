import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-balance-sheet-report',
  templateUrl: './balance-sheet-report.component.html',
  styleUrls: ['./balance-sheet-report.component.scss']
})
export class BalanceSheetReportComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
