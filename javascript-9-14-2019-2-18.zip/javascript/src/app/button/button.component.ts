import { Component, OnInit } from '@angular/core';
import { IHeaderAngularComp } from "ag-grid-angular";
import { ChartService } from "../chart.service";

@Component({
  selector: 'app-button',
  templateUrl: './button.component.html',
  styleUrls: ['./button.component.scss']
})
export class ButtonComponent implements OnInit, IHeaderAngularComp {

  params: any;

  agInit(params: any): void {
    this.params = params;
  }

  constructor(private _CS: ChartService) { }

  ngOnInit() {
  }

  hideShowChart() {
    // inform app about button press
    this._CS.changeSource(this.params);
  }

}
