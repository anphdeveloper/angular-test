import { Component, AfterViewInit } from '@angular/core';
import { ICellRendererAngularComp } from "ag-grid-angular";

import * as React from 'react';
import * as ReactDOM from 'react-dom';
import * as uuid from 'uuid';

import { XYChart, BarSeries, AreaSeries } from '@data-ui/xy-chart';
import { ChartService } from '../chart.service';

declare var $: any;

@Component({
  selector: 'app-subchart',
  templateUrl: './subchart.component.html',
  styleUrls: ['./subchart.component.scss']
})
export class SubchartComponent implements ICellRendererAngularComp, AfterViewInit {
  params: any;
  paramData: any;
  rootDomID: string;
  groupId: number;
  show: boolean;
  rData: Array<number>;
  maxRendered: number;
  map: any;
  done: boolean = false;

  agInit(params): void {
    // Refers to column number as indexed starting from 0
    this.groupId = params.column.parent.groupId - 1;

    // Modifies params for convience
    this.params = params.value;

    // Generates random ID for containing div so there are no conflicts
    this.rootDomID = uuid.v1();

    // 
    this.show = true;

    /* Function generates a number in a normal distribution in range [min, max] with specified skew */
    function randn_bm(min, max, skew) {
      var u = 0, v = 0;
      while(u === 0) u = Math.random(); //Converting [0,1) to (0,1)
      while(v === 0) v = Math.random();
      let num = Math.sqrt( -2.0 * Math.log( u ) ) * Math.cos( 2.0 * Math.PI * v );
  
      num = num / 10.0 + 0.5; // Translate to 0 -> 1
      if (num > 1 || num < 0) num = randn_bm(min, max, skew); // resample between 0 and 1 if out of range
      num = Math.pow(num, skew); // Skew
      num *= max - min; // Stretch to fill range
      num += min; // offset to min
      return num;
    }

    // use this.params.number to generate appropiate amount of data
    if (this.params && this.params.number > 0) {
      this.rData = [];
      for (let i = 0; i < this.params.number; i++) {
        this.rData.push(randn_bm(0, 100, this.params.skew));
      }
      this.maxRendered = this.params.maxRendered || this.rData.length;
    }

    this.map = {};
  }

  refresh(params: any): boolean {
    throw new Error("Method not implemented.");
  }

  afterGuiAttached?(params?: import("ag-grid-community").IAfterGuiAttachedParams): void {
    throw new Error("Method not implemented.");
  }

  constructor(
    private _CS: ChartService
  ) {
  }

  ngAfterViewInit() {
    // get container of angular component
    const div = document.getElementById(this.rootDomID);
    
    // only load chart if data is supplied
    if (this.params && this.params.number > 0) {
      // subscribe to service to update on audit button press
      this._CS.sourceChanged$.subscribe(
        event => {
          // button works only if its in the same column group
          if (event.columnGroup && +event.columnGroup.groupId === this.groupId) {
            this.show = !this.show;
            // removes or renders component based on show
            if (!this.show) {
              ReactDOM.unmountComponentAtNode(div);
            } else {
              this.loadChart(0, div);
            }
          } else if (this.done) {
            this.loadChart(this.rData.length, div);
          }
        }, 
        err => console.log(err)
      );
      // renders immediately if this.show is set to true (it is false currently)
      if (this.show)
        this.loadChart(0, div);
    }
  }

  loadChart(i, div) {

    /* Function converts an index into a gradient color, and stores the value in map so that the value is not recomputed
       Algorithm is an adaption of python code from this resource: https://stackoverflow.com/questions/22607043/color-gradient-algorithm
    */
    function computeGradient(i, map) {

      function to_sRGB_f(x) {
          return x.map(z => z <= 0.0031308 ? 12.92*z : 1.055 * (Math.pow(z, (1/2.4))) - 0.055);
      }

      function to_sRGB(x) {
          return to_sRGB_f(x).map(z => Math.floor((255.9999 * z)));
      }

      function from_sRGB(x) {
          x = x.map(z => z / 255.0);
          return x.map(z => {
            var y;
            if (z <= 0.04045)
              y = z / 12.92;
            else
              y = Math.pow((z + 0.055) / 1.055, 2.4);
            return y;
          });
      }

      function lerp(color1, color2, frac) {
          return color1.map((z, i) => z * (1 - frac) + color2[i] * frac);
      }



      function perceptual_steps(color1, color2, step, steps) {
          const gamma = .43
          const color1_lin = from_sRGB(color1)
          const bright1 = [Math.pow(color1_lin.reduce((acc, n) => acc + n, 0), gamma)];
          const color2_lin = from_sRGB(color2)
          const bright2 = [Math.pow(color1_lin.reduce((acc, n) => acc + n, 0), gamma)];

          const intensity = lerp(bright1, bright2, step / steps).map(z => Math.pow(z, (1/gamma)));
          let color = lerp(color1_lin, color2_lin, step / steps);
          if (color.reduce((acc, z) => z + acc, 0) !== 0) {
            color = color.map(z => z * intensity[0] / color.reduce((acc, z) => z + acc, 0));
          }
          return to_sRGB(color);
      }

      if (!map[i]) {
        // using algorithm to generate gradient from red to green with 25 distinct points
        const color = perceptual_steps([255, 0, 0], [0, 255, 0], i, 25);
        map[i] = `rgb(${color[0]}, ${color[1]}, ${color[2]})`
      }
      return map[i];
    }

    /* Function creates the chart label */
    function getLabel(rendered, length) {
      return `${Number(rendered).toLocaleString("en-US")}/${Number(length).toLocaleString("en-US")} (${Math.floor(rendered / length * 1000) / 10}%)`;  
    }

    // saves start time for later
    const start = new Date();

    // process 51 data entries at a time
    const inc = 51;
    let rendered = 0;

    // create all 25 bins according to their gradient
    const bins = [];
    for (let j = 0; j < 25; j++) {
      bins.push({ x: j, y: 0, fill: computeGradient(j, this.map) });
    }

    // list of bars that are made black
    const updated = [];

    for (let k = 0; k < i && k < this.rData.length; k++) {
      // convert data from [0, 100] into one of 25 bins
      const index = Math.floor(this.rData[k] / 4);

      // skip updating bins once maxRendered is reached
      if (k >= this.maxRendered) {
        break;
      } else {
        // increases the bins y value as a fraction of the total amount of data
        // this ensures that all graphs have similiar max height
        bins[index].y += 1 / this.rData.length * 5;
      }
      rendered++;

      // choose first bar that wasn't rendered last time to be made black
      if (k >= i - inc && updated.length === 0) {
        updated.push(index);
        bins[index].fill = "black";
      }
    }

    // Stops rendering and updating if Audit is clicked (this.show is affected by press)
    if (this.show) {
      // Render once before update cycle
      this.render(bins, div, 1, getLabel(rendered, this.rData.length));

      // Replaces the fill of black bars back to the color determined by the gradient
      for (let n = 0; n < updated.length; n++) {
        bins[updated[n]].fill = computeGradient(updated[n], this.map);
      }

      // stop if all animations finished
      if (i >= this.rData.length) {
        this.render(bins, div, 1, getLabel(rendered, this.rData.length));
        this.done = true;
        return;
      }

      // compute time the calculations + render took
      const end = new Date();
      const delta = +end - +start;

      // set delay on next call at 60 fps and increment i by inc
      setTimeout(() => {
        this.loadChart(i + inc, div);
      }, 1000 / 60 - delta);
    }
  }

  /* Function renders data into data-ui chart appropiately */
  render(data, div, max, label) {
    ReactDOM.render(
      React.createElement("div", null,
        // svg container
        React.createElement(XYChart, {
          ariaLabel: "Bar Chart", // accessibility title
          width: div.offsetWidth, // set to width of container
          height: 52, // hardcoded based on row height for ag-grid
          margin: { top: 27, bottom: 0, right: 5, left: 5 },
          xScale: { type: "linear" },
          yScale: { type: "linear", includesZero: true, domain: [0, max] } // sets max height to be max
        }, 
          // component for bars
          React.createElement(BarSeries, {
            data: data,
            fill: "#63e6be",
            fillOpacity: 0.9
          }, null), 
          // component for line
          React.createElement(AreaSeries, {
            strokeWidth: 1.2,
            strokeOpacity: 1.0,
            stroke: "#099268",
            fill: "none",
            fillOpacity: 0.5,
            data: data
          }, null)
      ), 
      // data label for chart
      React.createElement("p", { className: "chart-label" }, label)
    ), div);
  }
}