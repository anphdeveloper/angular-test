import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { SubchartComponent } from './subchart.component';

describe('SubchartComponent', () => {
  let component: SubchartComponent;
  let fixture: ComponentFixture<SubchartComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ SubchartComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(SubchartComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
