import { Component, OnInit, ChangeDetectorRef, APP_ID } from '@angular/core';
import { AgGridAngular } from 'ag-grid-angular';
import { GridOptions, GridApi, ColumnApi } from "ag-grid-community";
import { SubchartComponent } from '../subchart/subchart.component';
import { ButtonComponent } from "../button/button.component";
import { ChartService } from '../chart.service';
import { ICellRendererAngularComp } from "ag-grid-angular";
import { DataService } from '../data.service';

@Component({
  selector: 'app-grid-chart',
  templateUrl: './grid-chart.component.html',
  styleUrls: ['./grid-chart.component.scss']
})
export class GridChartComponent implements OnInit {

  gridOptions: GridOptions
  rowData: any;

  // provides column information for every column
  columnDefs: any = [];

  gridApi: GridApi;
  colApi: ColumnApi;

  first: boolean = true;
  hidden: Array<boolean>;
  counter = 0;

  __height: number;

  constructor(private _CS: ChartService, private _DS: DataService) {
    // initializes the gridOptions
    this.gridOptions = <GridOptions>{
      columnDefs: this.columnDefs,
      defaultColDef: {
        sortable: true,
        resizable: true
      },
      rowSelection: 'multiple',
      rowHeight: 75,
      frameworkComponents: {
        lineChartLineRenderer: SubchartComponent,
        toggleHeaderRenderer: ButtonComponent
      }
    }

    this.__height = 98;

    // Creates array to tell which columns are hidden
    this.hidden = Array(4).fill(true);
  }

  onGridReady(params) {
    this.gridApi = params.api;
    this.colApi = params.columnApi;
    this.gridApi.setColumnDefs(this.columnDefs);
    this.onGridSizeChanged({
      columnApi: this.colApi,
      api: this.gridApi
    });
  }

  ngOnInit() {
    // runs when data is updated
      this._DS.sourceChanged$.subscribe((e) => {
        this.columnDefs = [];
        this.columnDefs.push({
          headerName: "",
          field: "rowNumber",
          resizable: true,
          minWidth: 35,
          width: 35,
          cellClass: "row-number"
        });
        this.columnDefs.push({
          headerName: e.nameLabel,
          cellClass: "name",
          field: "name",
          resizable: true,
        });
          e.cols.forEach((c, j) => {
            this.columnDefs.push({
              colId: j,
              headerName: 'Audit',
              headerGroupComponent: "toggleHeaderRenderer",
              resizable: true,
              children: [
                {
                  headerName: c,
                  headerClass: "colored-header",
                  resizable: true,
                  children: [
                    {
                      headerName: "Balance",
                      field: `cols.${j}.balance`,
                      resizable: true,
                    },
                    {
                      headerName: "Confidence",
                      field: `cols.${j}.confidence`,
                      resizable: true,
                      cellRenderer: 'lineChartLineRenderer',
                      hide: true
                    }
                  ]
                }
              ]
            }
          );
        });
        this.columnDefs.push({
          headerName: "Total",
          field: "totalbalance",
        })
        
          this.rowData = e.rowData;

          // creates variable to hold the totals
          const totals = {
            cols: [],
            totalBalance: 0
          }

          for (let j = 0; j < e.cols.length; j++) {
            totals.cols.push({ balance: 0 });
          }

          // iterate through each row and add its values to total
          // removes $ and , from balance first to prevent errors
          // adds it back in for the display
          // also adds row number field
          this.rowData = this.rowData.map((r, i) => {
            let s = 0;

            e.cols.forEach((c, i) => {
              if (r.cols[i] && r.cols[i].balance) {
                s += +r.cols[i].balance.replace(/[$,]/g, "");
                totals.cols[i].balance += +r.cols[i].balance.replace(/[$,]/g, "");
                r.cols[i].balance = Number(r.cols[i].balance.replace(/[$,]/g, "")).toLocaleString("en");
                if (r.cols[i].balance === "0") {
                  r.cols[i].balance = "";
                }
              }
            })

            totals.totalBalance += s;
            r.totalbalance = "$" + Number(s).toLocaleString("en");
            r.rowNumber = i + 1 < 10 ? "0" + (i + 1) : i + 1;
            return r;
          });

          // creates totals row
          this.rowData.push({
            name: 'Total Assets', 
            cols: totals.cols.map(d => { return { confidence: [], balance: "$" + Number(d.balance).toLocaleString("en") } }),
            noSubledger: '', 
            totalbalance: "$" + Number(totals.totalBalance).toLocaleString("en"),
            rowNumber: this.rowData.length + 1 < 10 ? "0" + (this.rowData.length + 1) : this.rowData.length + 1
          });

        this.__height = 108 + 74 * this.rowData.length;

        // update state
        this.gridOptions.rowData = this.rowData;

        const temp = Array(e.cols.length);

        for (let i = 0; i < e.cols.length; i++) {
          temp[i] = this.hidden[i] || true;
        }

        this.hidden = temp;
          
        // only redraw after the first time since its done automatically
        if (!this.first) {
          this.gridApi.setColumnDefs(this.columnDefs);
          this.onGridSizeChanged({
            columnApi: this.colApi,
            api: this.gridApi
          });
          this.gridApi.redrawRows();
        }

        this.first = false;
      });

    // runs when audit button is pressed
    this._CS.sourceChanged$.subscribe((e) => {
      // hides appropiate column
      this.hidden[+e.columnGroup.groupId / 2] = !this.hidden[+e.columnGroup.groupId / 2];
      // redraws the grid
      this.onGridSizeChanged({
        columnApi: this.colApi,
        api: this.gridApi
      });
    });

  }

  // handles responsiveness
  onGridSizeChanged(params) {
    // find width based on wrapper html div
    var gridWidth = document.getElementById("grid-wrapper").offsetWidth;

    var columnsToShow = [];
    var columnsToHide = [];
    var totalColsWidth = 0;

    var allColumns = params.columnApi.getAllColumns();
    // iterate through columns and determine if they are hidden by hidden array lookup
    for (var i = 0; i < allColumns.length; i++) {
      let column = allColumns[i];
      if ((!column.colId.includes(".confidence") || (!this.hidden[Math.floor(+column.originalParent.groupId / 2)] && gridWidth >= 700))) {
        totalColsWidth += column.getMinWidth();
        if (totalColsWidth > gridWidth) {
          columnsToHide.push(column.colId);
        } else {
          columnsToShow.push(column.colId);
        }
      } else {
        columnsToHide.push(column.colId);
      }
    }

    // hide columns that are hidden and show other columns columns
    params.columnApi.setColumnsVisible(columnsToShow, true);
    params.columnApi.setColumnsVisible(columnsToHide, false);

    // resizes columns to fit
    params.api.sizeColumnsToFit();
  }

}
