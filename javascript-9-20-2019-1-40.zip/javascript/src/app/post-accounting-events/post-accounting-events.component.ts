import { Component, OnInit } from '@angular/core';
import zenscroll from 'zenscroll';
import { any } from 'prop-types';

@Component({
  selector: 'app-post-accounting-events',
  templateUrl: './post-accounting-events.component.html',
  styleUrls: ['./post-accounting-events.component.scss']
})
export class PostAccountingEventsComponent implements OnInit {

  n: number = 1000;

  accountingNumber: number = 1000;
  subledgerNumber: number = 0;

  key: any;
  Arr = Array;
  active: boolean = false;
  accountingScroller: any;
  subledgerScroller: any;

  constructor() { }

  ngOnInit() {

  }

  start() {
    if (this.active) {
      return false;
    }

    const accountingTable = document.getElementById("accounting-table");
    const subledgerTable = document.getElementById("subledgerTable");

    this.accountingScroller = zenscroll.createScroller(accountingTable, 5, 0);
    this.subledgerScroller = zenscroll.createScroller(subledgerTable, 5, 0);

    this.doUpdate(this);
  }

  doUpdate(o) {
      const start = new Date();

      const inc = 1;
  
      o.active = true;

      if (o.subledgerNumber >= o.n) {
        o.active = false;
        o.accountingScroller.stop();
        o.subledgerScroller.stop();
        return;
      }

      // setTimeout((o) => {
        const accountingTarget = document.getElementById(`accounting-${Math.min(o.n - 1, o.n - o.accountingNumber + inc)}`);
        o.accountingScroller.center(accountingTarget);

        const subledgerTarget = document.getElementById(`subledger-${Math.min(o.n - 1, o.n - o.accountingNumber + inc)}`);
        o.subledgerScroller.center(subledgerTarget);
      // }, 0, o);

      setTimeout((o) => {
        o.accountingNumber -= inc;
        o.subledgerNumber += inc;
      }, 1, o);

      setTimeout((start, o) => {
        o.doNextUpdate(start, o);
      }, 2, start, o);
  }

  doNextUpdate(start, o) {
    const end = new Date();
    const delta = +end - +start;

    if (o.active) {
      o.key = setTimeout(o.doUpdate, Math.max(0, 25 - delta), o);
    }
  }

  stop() {
    clearTimeout(this.key);
    this.active = false;
    this.accountingScroller.stop();
    this.subledgerScroller.stop();
  }

}
